pkg install nodejs
pkg install libwebp
pkg install ffmpeg
pkg install wget
npm install
npm start
